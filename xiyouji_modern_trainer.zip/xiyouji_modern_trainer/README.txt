西游记现代架构训练包（GQA + SwiGLU + RMSNorm + RoPE，纯 NumPy）
================================================================

这是什么
--------
把之前那份 Numba 现代架构草稿真正做成了能训练的版本：
- 完整手写反向传播（GQA / RoPE / SwiGLU / RMSNorm / 嵌入 / LM head），
  已通过数值梯度检验：6,776 个参数逐个对比有限差分，最大相对误差 1.15e-09。
- 纯 NumPy、不用 numba、没有 UI —— Pythonista 里可直接运行，不会闪退。

文件说明
--------
- modern_transformer_numpy.py  模型本体（前向 + 反向 + KV缓存生成 + Int8量化推理）
- train_modern.py              训练直跑脚本（无 UI，直接运行本文件即按 CONFIG 训练）
- generate_modern.py           加载 modern_ckpt.npz 生成文本
- check_modern_grads.py        梯度检验（电脑或手机上都能跑，约 7 秒）
- dual_transformer_numpy.py    只借用它的字符分词器与 AdamW 等工具
- Xiyouji.txt                  语料
- modern_ckpt.npz              已训练好的检查点（见下方成绩），可直接生成/续跑

已验证成绩（2026-10-22 本机实测）
--------------------------------
1) 同档对比（d=32 / 200步 / batch4 / seq32）：
   旧 Dual Transformer：验证 loss 8.56 → 6.8853，18.9s，338,720 参数
   本架构：            验证 loss 8.428 → 6.6356，11.3s，311,668 参数
   （注：学习率不同，本版 2e-3 vs 旧版 1e-3，属强指示而非严格对照）
2) 主训练（随包检查点）：d=64 / 2层 / Q头4 KV头2 / batch8 / seq64 /
   lr 3e-3 / 800步，668,264 参数，验证 loss 8.4262 → 5.2167，用时 381s。
   采样生成示例（prompt「悟空」，温度0.8）：
   「悟空。那个那呆子自在空中等我们的做个买卖上三藏与众风！”行者道：
     “你的茶！行李天是不爱衣服也！”菩萨道：“等在那里不能见那怪候。”…」
   （greedy 解码会退化成重复，属正常现象，用温度采样看效果。）

手机上怎么用
------------
1. 把本包所有文件放到 Pythonista3/Documents 同一目录。
2. 直接运行 generate_modern.py：立刻用已训练检查点生成文本。
3. 想自己训：直接运行 train_modern.py（默认 d=32 / 200步手机档，
   约 0.05-0.07 秒/步这一量级，本机测得；手机会慢一些）。
   改 CONFIG 可调步数/规模；跑完生成 modern_ckpt.npz，
   下次在命令里加 resume 或把 CONFIG 的 resume 改 True 可续跑。
4. 不要从 boot.py 里打开这些脚本，直接运行文件本身。

注意
----
- 本版是直接训练（AdamW + 梯度裁剪 + warmup/cosine），暂未接 Omega 门控。
- Int8 量化仅用于推理（训练请用 float）；小规模下 Int8 未必更快，
  它的价值在内存占用（权重 1 字节/参数）。
